//
// Created by Garrett Battaglia on 12/7/17.
//

#ifndef COLDBREW_HASH_H
#define COLDBREW_HASH_H

int hash_string(char *key);

#endif //COLDBREW_HASH_H
