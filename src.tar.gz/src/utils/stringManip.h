//
// Created by Garrett Battaglia on 12/18/17.
//

#ifndef COLDBREW_STRINGMANIP_H
#define COLDBREW_STRINGMANIP_H

char *lower_string(char *string);

#endif //COLDBREW_STRINGMANIP_H
